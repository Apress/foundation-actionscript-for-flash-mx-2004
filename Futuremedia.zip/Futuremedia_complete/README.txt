
===================================================================
Futuremedia Readme file
===================================================================

Contents

1. Introduction

2. Using the Site Files

3. Other Files

4. Changes to the Site

5. Updates

6. Contact
   

====================================================================
1. Introduction 
====================================================================

The files contained in Futuremedia_complete.zip are included as an
example of a site that uses the user interface developed in the 
book foundation ActionScript for Flash MX2004. 

You are free to use the Flash files as the basis for your own site.

====================================================================
2. Using the Site Files
====================================================================

To view the finished site you can
  
  Double-click on index.html
  
  With all files in the original directory structure, open index.fla 
  in Flash and test it with Control > Test Movie.  
  
  As above, but run main.fla.  You will need to right-click on 
  main.fla and select play to start the site (this is automatically 
  done by index.swf in normal operation).

  NB - The site uses a font symbol (to share the font between 
  seperately loaded levels).  Font symbols do not always work in 
  test movie, although they do work when you view the site in a 
  browser.  If you see blank areas in the site where you would expect
  text, test the site in a browser.

To Publish the site on the web, you need to upload the following files 
to your server

  The HTML file index.html
  
  The SWF files 
    index.swf
    main.swf
    burnmedia_burn.swf 
    burnmedia_game.swf   
    burnmedia_monster.swf 
    linksBack.swf
    The contents of folder 'drac (which must also be in a folder called      
    'drac')

  The JPEG image files (this list includes all JPG files in the zip)
    ASS.jpg
    drac.jpg
    DS.jpg
    FAS_J.jpg
    FDAR.jpg
    FGS.jpg
    fingertips.jpg
    flashhacks.jpg
    FoundationFlash_pol.jpg
    FPS.jpg
    FS.jpg
    FUE.jpg
    NMOF.jpg
    no_image.jpg
    RSML.jpg
    sham.jpg
   
You DO NOT need to upload the .as, .txt (this file) or .fla files.
  
====================================================================
3. Other Files
====================================================================
  
The burnmediaTemplate.fla file is an example of how you would start
creating your own content for the user interface.  you would first 
create a file such as burnmediaTemplate as your starting point.

====================================================================
4. Changes to the Site
====================================================================
The following lines have been changed in this site, and are different 
to the listing developed in the book.

to see the listing open main.fla and select frame 2 of layer actions.
the following lines are different (changes are commented in the code)

Lines 174-178
Lines 233-238 

====================================================================
5. Site Updates
====================================================================

If you see major differences between the site created by these files
and the site seen at www.futuremedia.org.uk, the author has updated 
the site.  You can get the up to date site files by opening the site
at www.futuremedia.org.uk, navigating to 

home > futuremedia > burnmedia 

and clicking on the word 'free' to the right of the fire graphic.

The site files for version 1.0 of the site (this version) will 
always be available at the downloads page for this book: 

www.friendsofed.com/books/1590593057/code.html.


====================================================================
6. Contact
====================================================================

For technical advice, inspiration, and sharing ideas, visit the 
friends of ED forums:

http://www.friendsofed.com/forums


   